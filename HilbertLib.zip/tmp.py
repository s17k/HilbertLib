while True:
	x,y,z = raw_input().split()
	print int(float(x)*10000), int(float(y)*10000), int(float(z)*10000)
